-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 22, 2018 at 01:40 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `social_network`
--

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `comment_id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `comment` int(100) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `pk_contact` int(11) NOT NULL,
  `name` varchar(120) DEFAULT NULL,
  `email` varchar(120) DEFAULT NULL,
  `website` varchar(120) DEFAULT NULL,
  `message` varchar(300) DEFAULT NULL,
  `added_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `msg_id` int(11) NOT NULL,
  `sender` varchar(255) NOT NULL,
  `reciver` varchar(255) NOT NULL,
  `msg_sub` text NOT NULL,
  `msg_topic` text NOT NULL,
  `reply` text NOT NULL,
  `status` text NOT NULL,
  `msg_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `topic_id` text NOT NULL,
  `post_title` text NOT NULL,
  `post_content` text NOT NULL,
  `post_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`post_id`, `user_id`, `topic_id`, `post_title`, `post_content`, `post_date`) VALUES
(25, 10, '2', 'Assalam o Alikum Everyone', 'kaya hal chal ha sub ka???', '2018-06-11 04:24:16'),
(26, 10, '1', 'Web class', 'HTML , CSS , JS , PHP , DB', '2018-06-11 04:26:18'),
(30, 10, '2', 'hello', 'aaaaaaaaaaaaaaaaaaaaaaaaa', '2018-06-11 04:28:15'),
(31, 11, '2', 'About Today', 'OHH Cool weather..  Amazing', '2018-06-11 04:46:49'),
(32, 11, '2', 'Ramdan Kareem', 'There going last #ASHRA of RAMDAN', '2018-06-11 04:47:48'),
(33, 11, '1', 'WEB ENGINEERNING', 'IT includes Html,CSS,JAVAScript,DB,PHP', '2018-06-11 04:49:11'),
(34, 11, '1', 'Final Exams', 'its time for chill.. after a boring routin\r\ncz final\'z ended', '2018-06-11 04:50:41'),
(35, 12, '2', 'Greetings', 'Morning Everyone', '2018-06-11 04:52:53'),
(36, 12, '1', 'LAB Sessionals', 'THere going lab sessionals..', '2018-06-11 04:53:53'),
(37, 12, '1', 'Mechanical Engineering', 'Bhaii bara scope haii..  CS sy axhii field hai..\r\n(Said by Shery Khan Lodhi)', '2018-06-11 04:56:02'),
(38, 13, '2', 'Ramdan Kareem', 'LAST #ASHRA .. Pray for you and for every Muslim ', '2018-06-11 04:59:10'),
(39, 13, '1', 'WEB', 'HATE this course......hhuuhh', '2018-06-11 04:59:52'),
(40, 13, '2', 'EID Greetings', 'Advance EID Mubarak to all friends with all the years..heheh', '2018-06-11 05:01:05'),
(41, 14, '1', 'WEB COURSE', 'Its great time with you B6.. Good luck for future', '2018-06-11 05:04:00'),
(42, 14, '1', 'FeedBAck', 'POST here your experiance of this semester', '2018-06-11 05:05:24'),
(43, 15, '1', 'WEB LAB', 'Guys its last spending day with you.. \r\nczz its going final lab sessional', '2018-06-11 05:08:06'),
(44, 15, '1', 'FeedBAck', 'Everyone Share his or her experiance here', '2018-06-11 05:09:18'),
(45, 15, '2', 'GOOD LUCK', 'cool down guys and have a long term chill', '2018-06-11 05:10:09'),
(46, 17, '2', 'Greetingss', 'Morning guyss...', '2018-06-11 05:14:31'),
(47, 19, '2', 'Cricket Match', 'About Today\'s match.....', '2018-06-21 08:10:24'),
(49, 10, '2', 'EID', 'Eid Mubarak to all classfellows.....', '2018-06-21 08:12:34');

-- --------------------------------------------------------

--
-- Table structure for table `topics`
--

CREATE TABLE `topics` (
  `topic_id` int(11) NOT NULL,
  `topic_title` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `topics`
--

INSERT INTO `topics` (`topic_id`, `topic_title`) VALUES
(1, 'Education'),
(2, 'Entertainment');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `u_name` varchar(100) NOT NULL,
  `u_pass` varchar(100) NOT NULL,
  `u_email` varchar(100) NOT NULL,
  `u_country` varchar(100) NOT NULL,
  `u_gender` varchar(100) NOT NULL,
  `u_birthday` date NOT NULL,
  `u_image` text NOT NULL,
  `registration_date` date NOT NULL,
  `last_login` date NOT NULL,
  `status` text NOT NULL,
  `posts` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `u_name`, `u_pass`, `u_email`, `u_country`, `u_gender`, `u_birthday`, `u_image`, `registration_date`, `last_login`, `status`, `posts`) VALUES
(10, 'Azeem Shahzad', '123456789', 'azeemshahzad@gmail.com', 'Pakistan', 'Male', '1996-08-15', 'IMG_5435.jpg', '2018-06-11', '2018-06-11', 'unverified', 'yes'),
(11, 'M Osman', 'usman12345', 'usman@gmail.com', 'USA', 'Male', '1667-03-06', 'Osman.jpg', '2018-06-11', '2018-06-11', 'unverified', 'yes'),
(12, 'SH khan', '123456789', 'khan@gmail.com', 'Dubai', 'Male', '1996-05-25', '15325338_1232220840205909_593752147989453518_o.jpg', '2018-06-11', '2018-06-11', 'unverified', 'yes'),
(13, 'Alisha Khan', '123456789', 'alisha123@yahoo.com', 'India', 'Female', '1998-05-05', 'alisha.jpg', '2018-06-11', '2018-06-11', 'unverified', 'yes'),
(14, 'Mr Nizam', '123456789', 'nizam@outlook.com', 'UK', 'Male', '1980-06-22', 'nizam.jpg', '2018-06-11', '2018-06-11', 'unverified', 'yes'),
(15, 'Mr Yasir', '123456789', 'yasir@gmail.com', 'India', 'Male', '1990-02-05', 'yasir.jpg', '2018-06-11', '2018-06-11', 'unverified', 'yes'),
(16, 'Gul Khan', '123456789', 'gul@gamil.com', 'Pakistan', 'Female', '1997-05-05', 'default.jpg', '2018-06-11', '2018-06-11', 'unverified', 'No'),
(17, 'KIRAN GUL', '123456789', 'kiran@gmail.com', 'Dubai', 'Female', '1996-07-02', 'gul.jpg', '2018-06-11', '2018-06-11', 'unverified', 'yes'),
(19, 'Hamad', 'hamad1234', 'hamad69@gmail.com', 'USA', 'Male', '1997-12-02', '20160811_150731_HDR.jpg', '2018-06-21', '2018-06-21', 'unverified', 'yes');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`comment_id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`pk_contact`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`msg_id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`post_id`);

--
-- Indexes for table `topics`
--
ALTER TABLE `topics`
  ADD PRIMARY KEY (`topic_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `comment_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `pk_contact` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `msg_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `post_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `topics`
--
ALTER TABLE `topics`
  MODIFY `topic_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
